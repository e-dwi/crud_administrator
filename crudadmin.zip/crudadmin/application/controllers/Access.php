<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Access extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_validation');
    }  
    
    public function index()
    {
         $this->load->view('access/login');
    }
    
    public function validate() {
        $this->form_validation->set_rules('usermail', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('userpass', 'Password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('access/login');
        }else{
            redirect('dashboard');
        }
    }
    public function login()
   {
        // create the data object
        $data = new stdClass();
        
        // load form helper and validation library
        $this->load->helper('form');
        $this->load->library('form_validation');
        
        // set validation rules
        $this->form_validation->set_rules('usermail', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('userpass', 'Password', 'required');
        
        if ($this->form_validation->run() == false) {
            
            // validation not ok, send validation errors to the view
            $this->load->view('access/login');
            
        } else {
            
            // set variables from the form
            $email = $this->input->post('usermail');
            $password = $this->input->post('userpass');
            
            if ($this->Login_model->resolve_admin_login($email, $password)) {
                
               // $user_id = $this->user_model->get_user_id_from_username($username);
                $user    = $this->Login_model->get_user($email);
                $newSession= array(
                                    'id_log'    => (int)$user->id_admin,
                                    'username_log'   => (string)$user->username,
                                   'logged_in'   => (bool)true);
                $this->session->set_userdata($newSession);
                redirect('Dashboard');
                
            } else {
                
                // login failed
                $data->error = 'Wrong username or password.';
                
                // send error to the view
                $this->load->view('access/login');
                
            }
            
        }
        
    }
    public function logout() {
        
        // create the data object
        $data = new stdClass();
        
        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
            
            // remove session datas
            foreach ($_SESSION as $key => $value) {
                unset($_SESSION[$key]);
            }
            
            // user logout ok
            redirect(base_url('Access'));
            
        } else {
            
            // there user was not logged in, we cannot logged him out,
            // redirect him to site root
            redirect('/');
            
        }
        
    }
 public function cek_login() {
 if($this->CI->session->userdata('username') == '') {
 $this->CI->session->set_flashdata('sukses','Anda belum login');
 redirect(base_url('login'));
 }
 }
    /*----------------------
        Register
    ------------------------*/
    public function register()
    {
            $this->load->view('access/register');
    }
    public function register_proses()
    {
        // $password = $this->input->post('password');
        // $dataUser = array('password'=>$this->hash_password($password));

        $data=array('id_admin'=>'',
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'username' => $this->input->post('username'),
                'password' =>$this->hash_password($this->input->post('password')),
            );
    
          $insert = $this->Admin_model->insert('admin',$data);
         redirect(base_url('access/login'));
    }
   /*----------------------
        Lupa password
    ------------------------*/
    public function lupa_password()
    {
            $this->load->view('access/lupa_password');
    }
    public function lupa_password_proses()
    {
        $email = $this->input->post('email');
        //$encrypted_id = md5($email);
        $get_data = $this->Login_model->get_user($email);
        if(empty($get_data))
        {
            print "<script type=\"text/javascript\">alert('Email Anda Belum Terdaftar');window.location = 'login(command)';</script>";
        }
        else
        {
            $username = $get_data->username;
            $encrypted_id = md5($get_data->id_admin);
            $htmlContent = 'Reset Password MyProject<br>';
            $htmlContent .= 'Username Anda : '.$username.' <br>';
            $htmlContent .= 'Silahkan klik link berikut untuk melakukan reset password '.base_url("access/reset_password/$encrypted_id");

        $ci = get_instance();
        $ci->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "smtp.sendgrid.net";
        $config['smtp_port'] = "587";
        $config['smtp_user'] = "wahyu281";
        $config['smtp_pass'] = "Wahyu10411281";
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";
        
        
        $ci->email->initialize($config);
 
        $ci->email->from('noreply@MyProject.com', 'MyProject');
        
        $ci->email->to($email);
        $ci->email->subject('MyProject Reset Password');
        $ci->email->message($htmlContent);
        if ($this->email->send()) {
           print "<script type=\"text/javascript\">alert('Silahkan Cek Email Anda');window.location = 'login';</script>";
        } else {
           show_error($this->email->print_debugger());
        }
            
        }
    }
    public function reset_password($key)
    {
            $data['key'] = $key;
           
            $this->load->view('access/reset_password',$data);
           
    }
    public function reset_password_proses()
    {
        $id = $this->input->post('xx');
        $password = $this->input->post('password');
        $dataUser = array('password'=>$this->hash_password($password));
        $update = $this->Login_model->reset_password($id,$dataUser);
        if($update)
        {
            print "<script type=\"text/javascript\">alert('Reset Password Berhasil');window.location = 'login';</script>";
        }

    }
    private function hash_password($password) {
        
        return password_hash($password, PASSWORD_BCRYPT);
        
    }

}
