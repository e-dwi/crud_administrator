<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Pengguna extends CI_Controller {
 
    public function __construct()
    {
        parent::__construct();
        $this->load->model('pengguna_model','pengguna');
         if(!$this->session->userdata('id_log')){
                redirect('access/login');
            }
    }
    public function table()
    {
        return 'daftar_pengguna';
    }
    public function id()
    {
        return 'id_pengguna';
    }  
 
    public function index()
    {
       $this->load->view('design/header');
       $this->load->view('admin/pengguna_view');
       $this->load->view('design/footer');
    }
 
    public function ajax_list()
    {
        $list = $this->pengguna->get_datatables();
       // print_r($list);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $pengguna) {
            $no++;
            $row = array();
            $row[] =$no;
            $row[] = $pengguna->nama_pengguna;
            $row[] = $pengguna->telp_pengguna;
            $row[] = $pengguna->alamat_pengguna;

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_pengguna('."'".$pengguna->id_pengguna."'".')"><i class="glyphicon glyphicon-pencil"></i></a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_pengguna('."'".$pengguna->id_pengguna."'".')"><i class="glyphicon glyphicon-trash"></i></a>
                  <a class="btn btn-sm btn-info" href="javascript:void(0)" title="view" onclick="view_pengguna('."'".$pengguna->id_pengguna."'".')"><i class="glyphicon glyphicon-search"></i></a>';
         
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->pengguna->count_all(),
                        "recordsFiltered" => $this->pengguna->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
  public function ajax_view($id)
    {
        $data= $this->Admin_model->edit_data($id,$this->id(),$this->table());
      //  $data->date = ($data->date == '0000-00-00') ? '' : $data->date; // if 0000-00-00 set tu empty for datepicker compatibility
        $data1=array(
               'nama : '.$data->nama_pengguna,
                '<br/>',
                'Telepon : '.$data->telp_pengguna,
                '<br/>',
                'Alamat : '.$data->alamat_pengguna,
                '<br/>',
        );
        
        echo json_encode($data1);
    }
    public function ajax_edit($id)
    {
        $data= $this->Admin_model->edit_data($id,$this->id(),$this->table());
      //  $data->date = ($data->date == '0000-00-00') ? '' : $data->date; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
       
    }
 
    public function ajax_add()
    {
        $date = date('Y-m-d');
        $this->_validate();
        $data=array('id_pengguna'=>'',
                'nama_pengguna' => $this->input->post('nama_pengguna'),
                'telp_pengguna' => $this->input->post('telp_pengguna'),
                'alamat_pengguna' => $this->input->post('alamat_pengguna'),
            );
    
          $insert = $this->Admin_model->insert($this->table(),$data);

        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_update()
    {
         $this->_validate();
        $id=$this->input->post('id_pengguna');
       
        $data = array(
                'nama_pengguna' => $this->input->post('nama_pengguna'),
                'telp_pengguna' => $this->input->post('telp_pengguna'),
                'alamat_pengguna' => $this->input->post('alamat_pengguna'),
            );
        $this->Admin_model->update_data($id,$this->id(),'daftar_pengguna',$data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->Admin_model->delete_data($id,$this->id(),$this->table());
        echo json_encode(array("status" => TRUE));
    }
    
 
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
        if($this->input->post('nama_pengguna') == '')
        {
            $data['inputerror'][] = 'nama_pengguna';
            $data['error_string'][] = ' name is required';
            $data['status'] = FALSE;
        }
        if($this->input->post('telp_pengguna') == '')
        {
            $data['inputerror'][] = 'telp_pengguna';
            $data['error_string'][] = 'phone is required';
            $data['status'] = FALSE;
        }
 
        if($this->input->post('alamat_pengguna') == '')
        {
            $data['inputerror'][] = 'alamat_pengguna';
            $data['error_string'][] = 'Addess is required';
            $data['status'] = FALSE;
        }
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

 }
