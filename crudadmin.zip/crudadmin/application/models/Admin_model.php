<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Admin_model class.
 * Author : Wahyu Nurhoho
 * @extends CI_Model
 */



class Admin_model extends CI_Model {
	  /**
     * __construct function.
     * 
     * @access public
     * @return void
     */
    public function __construct() {
        
        parent::__construct();
        $this->load->database();
        
    }
    /*=============================
   
    ==============================*/
    public function insert($table,$data)
   	{
   		$this->db->insert($table,$data);
   		return $this->db->insert_id();
   	}
    public function get($table)
	{
		return $this->db->get($table)->result();
	}

    public function get_data($table,$condition,$value)
	{
		$this->db->where($condition,$value);
		return $this->db->get($table)->result();
	}
	public function update_data($id,$id_table,$table,$data)
	{
		$this->db->where($id_table, $id);
		return $this->db->update($table, $data);
	}
  public function delete_data($id,$id_table,$table)
  {
    $this->db->from($table);
    $this->db->where($id_table,$id);
    return $this->db->delete();
  }
  public function edit_data($id,$id_table,$table)
  {
    $this->db->from($table);
    $this->db->where($id_table,$id);
    return $this->db->get()->row();
  }
   /*=============================
   
    ==============================*/

}// akhir


