<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Admin_model class.
 * Author : Wahyu Nurhoho
 * @extends CI_Model
 */



class Login_model extends CI_Model {
	  /**
     * __construct function.
     * 
     * @access public
     * @return void
     */
    public function __construct() {
        
        parent::__construct();
        $this->load->database();
        
    }
    /*=============================
    Login
    ==============================*/
    	public function resolve_admin_login($email, $password) {
		
		$this->db->select('password');
		$this->db->from('admin');
		$this->db->where('email', $email);
		
		$hash = $this->db->get()->row('password');
		
		return $this->verify_password_hash($password, $hash);
		
	}
	public function get_user($email)
	{
		$this->db->where('email',$email);
		return $this->db->get('admin')->row();
	}
	 
/**
	 * hash_password function.
	 * 
	 * @access private
	 * @param mixed $password
	 * @return string|bool could be a string on success, or bool false on failure
	 */
	private function hash_password($password) {
		
		return password_hash($password, PASSWORD_BCRYPT);
		
	}
	
	/**
	 * verify_password_hash function.
	 * 
	 * @access private
	 * @param mixed $password
	 * @param mixed $hash
	 * @return bool
	 */
	private function verify_password_hash($password, $hash) {
		
		return password_verify($password, $hash);
		
	}
	public function reset_password($id,$dataUser)
	{
			$this->db->where('md5(id_admin)', $id);
			return $this->db->update('admin', $dataUser);
	}

}


